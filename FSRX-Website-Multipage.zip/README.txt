FSRX WEBSITE STARTER

Files:
- index.html (homepage)
- departments.html
- applications.html
- team.html
- handbook.html
- updates.html
- marketplace.html
- styles.css
- script.js

Brand colours:
- Accent blue: #81b6ff
- Light grey background: #f1f3f6
- White content surfaces and dark navy text

BEFORE PUBLISHING:
1. Replace every occurrence of https://discord.gg/REPLACE-ME with your real FSRX Discord invite.
2. Confirm the department names and descriptions on departments.html.
3. Replace sample content and placeholders with official FSRX information.
4. Add your own logo, staff photos, update posts, application links, and marketplace details.
5. Upload all files to one GitHub repository and enable GitHub Pages (Settings > Pages).

The website's homepage can be used as the Roblox OAuth app entry link. The OAuth redirect/callback URL is separate and should remain the stable callback endpoint configured in your Roblox app.
